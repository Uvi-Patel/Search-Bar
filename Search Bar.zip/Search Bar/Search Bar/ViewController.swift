//
//  ViewController.swift
//  Search Bar
//
//  Created by MAC on 01/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var arr = ["Apple1","Ball","Bat","Cat","Cow","Cricket","Dog","Donkey","Elephant","Egg","Earn","Fan","Fruti","Got","Guava","Hen","Height","Ink","Jug","Junggle","Joker","Kite","King","Lamon","Latter","Life","Lotry","Monkey","Moon","Mango","Married","Nife","Nose","Notice","Orange","Ox","Open","Pepole","Parot","Pencil","Pen","Plat","Queen","Quite","Rain","Rainboew","Rabbit","Rose","Red","Ring","Range","Soon","Staturday","Sunday","Sun","Senta","Tiger","Ten","Tower","Tax","Table","Tom","Umbrella","Villege","Ven","Window","Wix","Xrey","Yaak","Yellow","Zebra","Zandu","Green","Maroon"]
    
    var filterarr:[String] = []
    
    var search: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(search) {
            return filterarr.count
        }
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! myCell
        if(search){
            cell.lbl.text = filterarr[indexPath.row]
            
        } else {
            cell.lbl.text = arr[indexPath.row]
        }
        return cell
    }
//
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//         filter = arr.filter({ (text) -> Bool in
//            let tmp: NSString = text as NSString
//            let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
//
//                   return range.location != NSNotFound
//               })
//
//               if(filter.count == 0){
//                   search = false;
//
//               } else {
//                   search = true;
//               }
//
//               self.tableView.reloadData()
//    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print("textDidChange")
//           filter = arr.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
        filterarr = arr.filter({$0.localizedCaseInsensitiveContains(searchBar.text!)})
        
        if(filterarr.count == 0){
            search = false;
        }
        else {
            search = true;
        }
        
        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchText)
        let newArray = (arr as NSArray).filtered(using: searchPredicate)

        filterarr = newArray as! [String]
        
        if searchText != ""
        {
            if filterarr.count == 0
            {
                filterarr.removeAll()
                self.tableView.isHidden = true
            }
            
        }
        else{
        
            filterarr.removeAll()
            self.tableView.isHidden = false
        }
        
        tableView.reloadData()
        
       }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        print("searchBarShouldBeginEditing")
        return true
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        print("searchBarTextDidBeginEditing")
    }

    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool{
        print("searchBarShouldEndEditing")
        return true
    }

    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        print("searchBarTextDidEndEditing")
    }

    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool{
        print("shouldChangeTextIn")
        return true
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
           print("searchBarSearchButtonClicked")
    }
    
    func searchBarBookmarkButtonClicked(_ searchBar: UISearchBar){
        print("searchBarBookmarkButtonClicked")
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar){
        print("searchBarCancelButtonClicked")
    }

    func searchBarResultsListButtonClicked(_ searchBar: UISearchBar){
        print("searchBarResultsListButtonClicked")
    }
         
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int){
        print("selectedScopeButtonIndexDidChange")
    }
     
}
class myCell: UITableViewCell
{
    @IBOutlet weak var lbl: UILabel!
}

